﻿namespace ProjectP
{
    partial class TaskManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvOrderDetails = new System.Windows.Forms.DataGridView();
            groupBox3 = new System.Windows.Forms.GroupBox();
            btnResetFilter = new System.Windows.Forms.Button();
            btnDeleteOrderDetail = new System.Windows.Forms.Button();
            ddlFilterCustomer = new System.Windows.Forms.ComboBox();
            btnEditOrderDetail = new System.Windows.Forms.Button();
            label4 = new System.Windows.Forms.Label();
            btnAddOrderDetail = new System.Windows.Forms.Button();
            btnFilter = new System.Windows.Forms.Button();
            txtFilterOrderNo = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            btnSave = new System.Windows.Forms.Button();
            lblOrderID = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)dgvOrderDetails).BeginInit();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // dgvOrderDetails
            // 
            dgvOrderDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dgvOrderDetails.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            dgvOrderDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOrderDetails.Location = new System.Drawing.Point(15, 153);
            dgvOrderDetails.MultiSelect = false;
            dgvOrderDetails.Name = "dgvOrderDetails";
            dgvOrderDetails.ReadOnly = true;
            dgvOrderDetails.RowTemplate.Height = 25;
            dgvOrderDetails.Size = new System.Drawing.Size(724, 223);
            dgvOrderDetails.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(btnResetFilter);
            groupBox3.Controls.Add(btnDeleteOrderDetail);
            groupBox3.Controls.Add(ddlFilterCustomer);
            groupBox3.Controls.Add(btnEditOrderDetail);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(btnAddOrderDetail);
            groupBox3.Controls.Add(btnFilter);
            groupBox3.Controls.Add(dgvOrderDetails);
            groupBox3.Controls.Add(txtFilterOrderNo);
            groupBox3.Controls.Add(label2);
            groupBox3.Location = new System.Drawing.Point(2, 43);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new System.Drawing.Size(762, 400);
            groupBox3.TabIndex = 31;
            groupBox3.TabStop = false;
            groupBox3.Text = "Task";
            // 
            // btnResetFilter
            // 
            btnResetFilter.BackColor = System.Drawing.Color.WhiteSmoke;
            btnResetFilter.FlatAppearance.BorderSize = 0;
            btnResetFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnResetFilter.ForeColor = System.Drawing.Color.Black;
            btnResetFilter.Location = new System.Drawing.Point(629, 39);
            btnResetFilter.Name = "btnResetFilter";
            btnResetFilter.Size = new System.Drawing.Size(108, 23);
            btnResetFilter.TabIndex = 30;
            btnResetFilter.Text = "Reset / Refresh";
            btnResetFilter.UseVisualStyleBackColor = false;
            // 
            // btnDeleteOrderDetail
            // 
            btnDeleteOrderDetail.BackColor = System.Drawing.Color.FromArgb(47, 152, 198);
            btnDeleteOrderDetail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDeleteOrderDetail.ForeColor = System.Drawing.Color.White;
            btnDeleteOrderDetail.Location = new System.Drawing.Point(305, 96);
            btnDeleteOrderDetail.Name = "btnDeleteOrderDetail";
            btnDeleteOrderDetail.Size = new System.Drawing.Size(133, 30);
            btnDeleteOrderDetail.TabIndex = 24;
            btnDeleteOrderDetail.Text = "Delete Line";
            btnDeleteOrderDetail.UseVisualStyleBackColor = false;
            // 
            // ddlFilterCustomer
            // 
            ddlFilterCustomer.FormattingEnabled = true;
            ddlFilterCustomer.Location = new System.Drawing.Point(352, 43);
            ddlFilterCustomer.Name = "ddlFilterCustomer";
            ddlFilterCustomer.Size = new System.Drawing.Size(176, 23);
            ddlFilterCustomer.TabIndex = 29;
            // 
            // btnEditOrderDetail
            // 
            btnEditOrderDetail.BackColor = System.Drawing.Color.FromArgb(47, 152, 198);
            btnEditOrderDetail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnEditOrderDetail.ForeColor = System.Drawing.Color.White;
            btnEditOrderDetail.Location = new System.Drawing.Point(166, 96);
            btnEditOrderDetail.Name = "btnEditOrderDetail";
            btnEditOrderDetail.Size = new System.Drawing.Size(133, 30);
            btnEditOrderDetail.TabIndex = 23;
            btnEditOrderDetail.Text = "Edit Task";
            btnEditOrderDetail.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(219, 47);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(112, 15);
            label4.TabIndex = 28;
            label4.Text = "Filter by Task Name:";
            // 
            // btnAddOrderDetail
            // 
            btnAddOrderDetail.BackColor = System.Drawing.Color.FromArgb(47, 152, 198);
            btnAddOrderDetail.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnAddOrderDetail.ForeColor = System.Drawing.Color.White;
            btnAddOrderDetail.Location = new System.Drawing.Point(27, 96);
            btnAddOrderDetail.Name = "btnAddOrderDetail";
            btnAddOrderDetail.Size = new System.Drawing.Size(133, 30);
            btnAddOrderDetail.TabIndex = 22;
            btnAddOrderDetail.Text = "Create Task";
            btnAddOrderDetail.UseVisualStyleBackColor = false;
            // 
            // btnFilter
            // 
            btnFilter.BackColor = System.Drawing.Color.FromArgb(47, 152, 198);
            btnFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnFilter.ForeColor = System.Drawing.Color.White;
            btnFilter.Location = new System.Drawing.Point(548, 39);
            btnFilter.Name = "btnFilter";
            btnFilter.Size = new System.Drawing.Size(75, 23);
            btnFilter.TabIndex = 27;
            btnFilter.Text = "Filter";
            btnFilter.UseVisualStyleBackColor = false;
            // 
            // txtFilterOrderNo
            // 
            txtFilterOrderNo.Location = new System.Drawing.Point(140, 43);
            txtFilterOrderNo.Name = "txtFilterOrderNo";
            txtFilterOrderNo.Size = new System.Drawing.Size(66, 23);
            txtFilterOrderNo.TabIndex = 26;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(31, 47);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(88, 15);
            label2.TabIndex = 25;
            label2.Text = "Filter by TaskID:";
            // 
            // btnSave
            // 
            btnSave.BackColor = System.Drawing.Color.FromArgb(1, 90, 132);
            btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnSave.ForeColor = System.Drawing.Color.White;
            btnSave.Location = new System.Drawing.Point(17, 463);
            btnSave.Name = "btnSave";
            btnSave.Size = new System.Drawing.Size(105, 40);
            btnSave.TabIndex = 30;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = false;
            // 
            // lblOrderID
            // 
            lblOrderID.AutoSize = true;
            lblOrderID.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblOrderID.Location = new System.Drawing.Point(253, 3);
            lblOrderID.Name = "lblOrderID";
            lblOrderID.Size = new System.Drawing.Size(127, 25);
            lblOrderID.TabIndex = 34;
            lblOrderID.Text = "ProjectName";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(2, 3);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(223, 25);
            label1.TabIndex = 33;
            label1.Text = "Adding Task to Project: ";
            // 
            // btnCancel
            // 
            btnCancel.BackColor = System.Drawing.Color.Gainsboro;
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnCancel.ForeColor = System.Drawing.Color.Black;
            btnCancel.Location = new System.Drawing.Point(622, 463);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new System.Drawing.Size(105, 40);
            btnCancel.TabIndex = 32;
            btnCancel.Text = "Cancel";
            btnCancel.UseVisualStyleBackColor = false;
            // 
            // TaskManage
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(799, 514);
            Controls.Add(groupBox3);
            Controls.Add(btnSave);
            Controls.Add(lblOrderID);
            Controls.Add(label1);
            Controls.Add(btnCancel);
            Name = "TaskManage";
            Text = "TaskManage";
            ((System.ComponentModel.ISupportInitialize)dgvOrderDetails).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.DataGridView dgvOrderDetails;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnResetFilter;
        private System.Windows.Forms.Button btnDeleteOrderDetail;
        private System.Windows.Forms.ComboBox ddlFilterCustomer;
        private System.Windows.Forms.Button btnEditOrderDetail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnAddOrderDetail;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.TextBox txtFilterOrderNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCancel;
    }
}