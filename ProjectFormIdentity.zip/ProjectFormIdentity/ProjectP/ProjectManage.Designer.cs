﻿namespace ProjectP
{
    partial class ProjectManage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvProjects = new System.Windows.Forms.DataGridView();
            label2 = new System.Windows.Forms.Label();
            groupBox1 = new System.Windows.Forms.GroupBox();
            btnResetFilter = new System.Windows.Forms.Button();
            ddlFilterCustomer = new System.Windows.Forms.ComboBox();
            label4 = new System.Windows.Forms.Label();
            btnFilter = new System.Windows.Forms.Button();
            txtFilterOrderNo = new System.Windows.Forms.TextBox();
            btnEditOrder = new System.Windows.Forms.Button();
            btnClose = new System.Windows.Forms.Button();
            btnDelete = new System.Windows.Forms.Button();
            btnDetails = new System.Windows.Forms.Button();
            btnAdd = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)dgvProjects).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvProjects
            // 
            dgvProjects.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dgvProjects.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            dgvProjects.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProjects.Location = new System.Drawing.Point(12, 77);
            dgvProjects.MultiSelect = false;
            dgvProjects.Name = "dgvProjects";
            dgvProjects.RowTemplate.Height = 25;
            dgvProjects.Size = new System.Drawing.Size(734, 376);
            dgvProjects.TabIndex = 24;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(6, 30);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(103, 15);
            label2.TabIndex = 2;
            label2.Text = "Filter by ProjectID:";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnResetFilter);
            groupBox1.Controls.Add(ddlFilterCustomer);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(btnFilter);
            groupBox1.Controls.Add(txtFilterOrderNo);
            groupBox1.Controls.Add(label2);
            groupBox1.Location = new System.Drawing.Point(12, 10);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new System.Drawing.Size(734, 61);
            groupBox1.TabIndex = 25;
            groupBox1.TabStop = false;
            groupBox1.Text = "Filters";
            // 
            // btnResetFilter
            // 
            btnResetFilter.BackColor = System.Drawing.Color.WhiteSmoke;
            btnResetFilter.FlatAppearance.BorderSize = 0;
            btnResetFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnResetFilter.ForeColor = System.Drawing.Color.Black;
            btnResetFilter.Location = new System.Drawing.Point(604, 22);
            btnResetFilter.Name = "btnResetFilter";
            btnResetFilter.Size = new System.Drawing.Size(108, 23);
            btnResetFilter.TabIndex = 10;
            btnResetFilter.Text = "Reset / Refresh";
            btnResetFilter.UseVisualStyleBackColor = false;
            // 
            // ddlFilterCustomer
            // 
            ddlFilterCustomer.FormattingEnabled = true;
            ddlFilterCustomer.Location = new System.Drawing.Point(327, 26);
            ddlFilterCustomer.Name = "ddlFilterCustomer";
            ddlFilterCustomer.Size = new System.Drawing.Size(176, 23);
            ddlFilterCustomer.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(194, 30);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(127, 15);
            label4.TabIndex = 7;
            label4.Text = "Filter by Project Name:";
            // 
            // btnFilter
            // 
            btnFilter.BackColor = System.Drawing.Color.FromArgb(47, 152, 198);
            btnFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnFilter.ForeColor = System.Drawing.Color.White;
            btnFilter.Location = new System.Drawing.Point(523, 22);
            btnFilter.Name = "btnFilter";
            btnFilter.Size = new System.Drawing.Size(75, 23);
            btnFilter.TabIndex = 6;
            btnFilter.Text = "Filter";
            btnFilter.UseVisualStyleBackColor = false;
            // 
            // txtFilterOrderNo
            // 
            txtFilterOrderNo.Location = new System.Drawing.Point(115, 26);
            txtFilterOrderNo.Name = "txtFilterOrderNo";
            txtFilterOrderNo.Size = new System.Drawing.Size(66, 23);
            txtFilterOrderNo.TabIndex = 5;
            // 
            // btnEditOrder
            // 
            btnEditOrder.BackColor = System.Drawing.Color.FromArgb(1, 90, 132);
            btnEditOrder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnEditOrder.ForeColor = System.Drawing.Color.White;
            btnEditOrder.Location = new System.Drawing.Point(108, 466);
            btnEditOrder.Name = "btnEditOrder";
            btnEditOrder.Size = new System.Drawing.Size(90, 42);
            btnEditOrder.TabIndex = 30;
            btnEditOrder.Text = "Edit Project";
            btnEditOrder.UseVisualStyleBackColor = false;
            // 
            // btnClose
            // 
            btnClose.BackColor = System.Drawing.Color.Gainsboro;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnClose.ForeColor = System.Drawing.Color.Black;
            btnClose.Location = new System.Drawing.Point(656, 466);
            btnClose.Name = "btnClose";
            btnClose.Size = new System.Drawing.Size(90, 42);
            btnClose.TabIndex = 29;
            btnClose.Text = "Close";
            btnClose.UseVisualStyleBackColor = false;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = System.Drawing.Color.Firebrick;
            btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDelete.ForeColor = System.Drawing.Color.White;
            btnDelete.Location = new System.Drawing.Point(367, 466);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new System.Drawing.Size(109, 42);
            btnDelete.TabIndex = 28;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = false;
            // 
            // btnDetails
            // 
            btnDetails.BackColor = System.Drawing.Color.FromArgb(1, 90, 132);
            btnDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDetails.ForeColor = System.Drawing.Color.White;
            btnDetails.Location = new System.Drawing.Point(206, 466);
            btnDetails.Name = "btnDetails";
            btnDetails.Size = new System.Drawing.Size(155, 42);
            btnDetails.TabIndex = 27;
            btnDetails.Text = "Add Tasks";
            btnDetails.UseVisualStyleBackColor = false;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = System.Drawing.Color.FromArgb(1, 90, 132);
            btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnAdd.ForeColor = System.Drawing.Color.White;
            btnAdd.Location = new System.Drawing.Point(10, 466);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new System.Drawing.Size(90, 42);
            btnAdd.TabIndex = 26;
            btnAdd.Text = "Create Project";
            btnAdd.UseVisualStyleBackColor = false;
            // 
            // ProjectManage
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(791, 545);
            Controls.Add(dgvProjects);
            Controls.Add(groupBox1);
            Controls.Add(btnEditOrder);
            Controls.Add(btnClose);
            Controls.Add(btnDelete);
            Controls.Add(btnDetails);
            Controls.Add(btnAdd);
            Name = "ProjectManage";
            Text = "ProjectManage";
            ((System.ComponentModel.ISupportInitialize)dgvProjects).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DataGridView dgvProjects;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnResetFilter;
        private System.Windows.Forms.ComboBox ddlFilterCustomer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnFilter;
        private System.Windows.Forms.TextBox txtFilterOrderNo;
        private System.Windows.Forms.Button btnEditOrder;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnDetails;
        private System.Windows.Forms.Button btnAdd;
    }
}