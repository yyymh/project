﻿namespace ProjectP
{
    partial class ProjectReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectReport));
            lblEmployeeName = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            panel1 = new System.Windows.Forms.Panel();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            btnDeleteDependant = new System.Windows.Forms.Button();
            label5 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            dgvDependants = new System.Windows.Forms.DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDependants).BeginInit();
            SuspendLayout();
            // 
            // lblEmployeeName
            // 
            lblEmployeeName.AutoSize = true;
            lblEmployeeName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblEmployeeName.Location = new System.Drawing.Point(238, 125);
            lblEmployeeName.Name = "lblEmployeeName";
            lblEmployeeName.Size = new System.Drawing.Size(130, 21);
            lblEmployeeName.TabIndex = 28;
            lblEmployeeName.Text = "lblProjectName";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(30, 125);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(123, 21);
            label1.TabIndex = 27;
            label1.Text = "Project Selected:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = System.Drawing.Color.Transparent;
            label4.Font = new System.Drawing.Font("Lucida Bright", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.White;
            label4.Location = new System.Drawing.Point(28, 26);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(377, 33);
            label4.TabIndex = 0;
            label4.Text = "Task Management System";
            // 
            // panel1
            // 
            panel1.BackgroundImage = (System.Drawing.Image)resources.GetObject("panel1.BackgroundImage");
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label4);
            panel1.Location = new System.Drawing.Point(2, 1);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(873, 84);
            panel1.TabIndex = 29;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(733, 69);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(82, 15);
            label6.TabIndex = 13;
            label6.Text = "Project Report";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(682, 228);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(46, 15);
            label7.TabIndex = 37;
            label7.Text = "Answer";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(682, 199);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(46, 15);
            label8.TabIndex = 36;
            label8.Text = "Answer";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(682, 169);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(46, 15);
            label9.TabIndex = 35;
            label9.Text = "Answer";
            // 
            // btnDeleteDependant
            // 
            btnDeleteDependant.BackColor = System.Drawing.Color.Firebrick;
            btnDeleteDependant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDeleteDependant.ForeColor = System.Drawing.Color.White;
            btnDeleteDependant.Location = new System.Drawing.Point(577, 409);
            btnDeleteDependant.Name = "btnDeleteDependant";
            btnDeleteDependant.Size = new System.Drawing.Size(283, 23);
            btnDeleteDependant.TabIndex = 34;
            btnDeleteDependant.Text = "Close";
            btnDeleteDependant.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(577, 228);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(105, 15);
            label5.TabIndex = 33;
            label5.Text = "Tasks per Member:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(577, 199);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(85, 15);
            label3.TabIndex = 32;
            label3.Text = "Overdue Tasks:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(577, 169);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(84, 15);
            label2.TabIndex = 31;
            label2.Text = "Tasks Pending:";
            // 
            // dgvDependants
            // 
            dgvDependants.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dgvDependants.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDependants.Location = new System.Drawing.Point(30, 169);
            dgvDependants.Name = "dgvDependants";
            dgvDependants.ReadOnly = true;
            dgvDependants.RowHeadersWidth = 82;
            dgvDependants.RowTemplate.Height = 25;
            dgvDependants.Size = new System.Drawing.Size(518, 263);
            dgvDependants.TabIndex = 30;
            // 
            // ProjectReport
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(877, 468);
            Controls.Add(lblEmployeeName);
            Controls.Add(label1);
            Controls.Add(panel1);
            Controls.Add(label7);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(btnDeleteDependant);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(dgvDependants);
            Name = "ProjectReport";
            Text = "ProjectReport";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDependants).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnDeleteDependant;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvDependants;
    }
}