﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using ProjectP.Models;

namespace ProjectP
{
    public partial class CreateProject : Form
    {
        TaskManagementDBContext context;
        Project projects;
        public CreateProject()
        {
            InitializeComponent();
            context = new TaskManagementDBContext();
            projects = new Project();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Create a new instance of your Project model and populate its properties with data from the form
            projects.ProjectName = txtProjectName.Text;
            projects.ProjectDescription = txtProjectDescription.Text;
            projects.StartDate = dtpStartDate.Value;
            projects.DueDate = dtpDueDate.Value;

            // Add the new project to the database and save changes
            context.Projects.Add(projects);
            context.SaveChanges();

            // Show a message box to confirm that the project was added successfully
            MessageBox.Show("Project added successfully!");

            // Clear the form fields for the next entry
            txtProjectName.Text = "";
            txtProjectDescription.Text = "";
            dtpStartDate.Value = DateTime.Now;
            dtpDueDate.Value = DateTime.Now;
        }
    }
    }
}
