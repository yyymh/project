﻿namespace ProjectP
{
    partial class HomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomePage));
            groupBox3 = new System.Windows.Forms.GroupBox();
            pictureBox3 = new System.Windows.Forms.PictureBox();
            label2 = new System.Windows.Forms.Label();
            groupBox1 = new System.Windows.Forms.GroupBox();
            groupBox2 = new System.Windows.Forms.GroupBox();
            btnManageOrders = new System.Windows.Forms.Button();
            label8 = new System.Windows.Forms.Label();
            btnChange = new System.Windows.Forms.Button();
            lblEmployeeName = new System.Windows.Forms.Label();
            panel1 = new System.Windows.Forms.Panel();
            label7 = new System.Windows.Forms.Label();
            btnRefresh = new System.Windows.Forms.Button();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox3
            // 
            groupBox3.BackColor = System.Drawing.Color.White;
            groupBox3.Controls.Add(pictureBox3);
            groupBox3.Controls.Add(label2);
            groupBox3.Location = new System.Drawing.Point(22, 36);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new System.Drawing.Size(461, 345);
            groupBox3.TabIndex = 14;
            groupBox3.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = System.Drawing.Color.White;
            pictureBox3.Image = (System.Drawing.Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new System.Drawing.Point(134, 36);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new System.Drawing.Size(181, 151);
            pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 11;
            pictureBox3.TabStop = false;
            // 
            // label2
            // 
            label2.Location = new System.Drawing.Point(87, 221);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(273, 76);
            label2.TabIndex = 1;
            label2.Text = "Manage Project";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = System.Drawing.Color.White;
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Font = new System.Drawing.Font("Sans Serif Collection", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            groupBox1.Location = new System.Drawing.Point(244, 103);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new System.Drawing.Size(516, 387);
            groupBox1.TabIndex = 21;
            groupBox1.TabStop = false;
            groupBox1.Text = "Dashboard";
            // 
            // groupBox2
            // 
            groupBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            groupBox2.Controls.Add(btnManageOrders);
            groupBox2.Font = new System.Drawing.Font("Sans Serif Collection", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            groupBox2.Location = new System.Drawing.Point(22, 102);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new System.Drawing.Size(204, 387);
            groupBox2.TabIndex = 22;
            groupBox2.TabStop = false;
            groupBox2.Text = "Project Menu";
            // 
            // btnManageOrders
            // 
            btnManageOrders.BackColor = System.Drawing.Color.FromArgb(1, 90, 132);
            btnManageOrders.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnManageOrders.ForeColor = System.Drawing.Color.White;
            btnManageOrders.Location = new System.Drawing.Point(21, 34);
            btnManageOrders.Name = "btnManageOrders";
            btnManageOrders.Size = new System.Drawing.Size(164, 50);
            btnManageOrders.TabIndex = 8;
            btnManageOrders.Text = "Project Report";
            btnManageOrders.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(549, 20);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(98, 29);
            label8.TabIndex = 10;
            label8.Text = "Welcome:";
            // 
            // btnChange
            // 
            btnChange.BackColor = System.Drawing.Color.WhiteSmoke;
            btnChange.FlatAppearance.BorderSize = 0;
            btnChange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnChange.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            btnChange.ForeColor = System.Drawing.Color.FromArgb(1, 90, 132);
            btnChange.Location = new System.Drawing.Point(656, 60);
            btnChange.Name = "btnChange";
            btnChange.Size = new System.Drawing.Size(104, 22);
            btnChange.TabIndex = 14;
            btnChange.Text = "Change";
            btnChange.UseVisualStyleBackColor = false;
            btnChange.Click += btnChange_Click;
            // 
            // lblEmployeeName
            // 
            lblEmployeeName.AutoSize = true;
            lblEmployeeName.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblEmployeeName.Location = new System.Drawing.Point(653, 27);
            lblEmployeeName.Name = "lblEmployeeName";
            lblEmployeeName.Size = new System.Drawing.Size(107, 15);
            lblEmployeeName.TabIndex = 11;
            lblEmployeeName.Text = "lblEmployeeName";
            // 
            // panel1
            // 
            panel1.BackgroundImage = (System.Drawing.Image)resources.GetObject("panel1.BackgroundImage");
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(btnChange);
            panel1.Controls.Add(lblEmployeeName);
            panel1.Font = new System.Drawing.Font("Sans Serif Collection", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            panel1.Location = new System.Drawing.Point(3, 2);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(768, 95);
            panel1.TabIndex = 24;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = System.Drawing.Color.Transparent;
            label7.Font = new System.Drawing.Font("Lucida Bright", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label7.ForeColor = System.Drawing.Color.White;
            label7.Location = new System.Drawing.Point(142, 27);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(377, 33);
            label7.TabIndex = 0;
            label7.Text = "Task Management System";
            // 
            // btnRefresh
            // 
            btnRefresh.BackColor = System.Drawing.Color.WhiteSmoke;
            btnRefresh.FlatAppearance.BorderSize = 0;
            btnRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnRefresh.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            btnRefresh.ForeColor = System.Drawing.Color.FromArgb(1, 90, 132);
            btnRefresh.Location = new System.Drawing.Point(644, 496);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new System.Drawing.Size(104, 22);
            btnRefresh.TabIndex = 23;
            btnRefresh.Text = "Refresh";
            btnRefresh.UseVisualStyleBackColor = false;
            // 
            // HomePage
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(776, 521);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            Controls.Add(panel1);
            Controls.Add(btnRefresh);
            Name = "HomePage";
            Text = "HomePage";
            Load += HomePage_Load;
            groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnManageOrders;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnChange;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnRefresh;
    }
}