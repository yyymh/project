﻿using Microsoft.AspNetCore.Identity;
using ProjectPBusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectP
{
    public static class Global
    {
        public static IdentityUser User;
    }
}
