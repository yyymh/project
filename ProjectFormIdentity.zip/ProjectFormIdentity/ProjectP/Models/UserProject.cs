﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ProjectP.Models
{
    [Table("User_Project")]
    public partial class UserProject
    {
        [Key]
        public int UserProjectId { get; set; }
        public int UserId { get; set; }
        public int ProjectId { get; set; }

        [ForeignKey(nameof(ProjectId))]
        [InverseProperty("UserProjects")]
        public virtual Project Project { get; set; }
        [ForeignKey(nameof(UserId))]
        [InverseProperty("UserProjects")]
        public virtual User User { get; set; }
    }
}
