﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ProjectP.Models
{
    [Table("Notification")]
    public partial class Notification
    {
        [Key]
        [Column("notificationId")]
        public int NotificationId { get; set; }
        [Column("notificationMessage")]
        [StringLength(50)]
        public string NotificationMessage { get; set; }
        [Column("notificationType")]
        [StringLength(50)]
        public string NotificationType { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("userId")]
        public int UserId { get; set; }

        [ForeignKey(nameof(UserId))]
        [InverseProperty("Notifications")]
        public virtual User User { get; set; }
    }
}
