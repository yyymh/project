﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ProjectP.Models
{
    [Table("Comment")]
    public partial class Comment
    {
        [Key]
        [Column("commentId")]
        public int CommentId { get; set; }
        [Column("commentDate", TypeName = "date")]
        public DateTime? CommentDate { get; set; }
        [Column("commentTime", TypeName = "date")]
        public DateTime? CommentTime { get; set; }
        [Column("userId")]
        public int UserId { get; set; }
        [Column("commentText")]
        [StringLength(150)]
        public string CommentText { get; set; }
        [Column("taskId")]
        public int TaskId { get; set; }

        [ForeignKey(nameof(TaskId))]
        [InverseProperty("Comments")]
        public virtual Task Task { get; set; }
        [ForeignKey(nameof(UserId))]
        [InverseProperty("Comments")]
        public virtual User User { get; set; }
    }
}
