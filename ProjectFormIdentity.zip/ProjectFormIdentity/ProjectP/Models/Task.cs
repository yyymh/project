﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ProjectP.Models
{
    [Table("Task")]
    public partial class Task
    {
        public Task()
        {
            Comments = new HashSet<Comment>();
            Documents = new HashSet<Document>();
        }

        [Key]
        [Column("taskId")]
        public int TaskId { get; set; }
        [Column("taskName")]
        [StringLength(50)]
        public string TaskName { get; set; }
        [Column("taskDescription")]
        [StringLength(50)]
        public string TaskDescription { get; set; }
        [Column("userId")]
        public int UserId { get; set; }
        [Column("status")]
        public bool? Status { get; set; }
        [Column("projectId")]
        public int ProjectId { get; set; }
        [Column("startDate", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("dueDate", TypeName = "date")]
        public DateTime? DueDate { get; set; }

        [ForeignKey(nameof(ProjectId))]
        [InverseProperty("Tasks")]
        public virtual Project Project { get; set; }
        [ForeignKey(nameof(UserId))]
        [InverseProperty("Tasks")]
        public virtual User User { get; set; }
        [InverseProperty(nameof(Comment.Task))]
        public virtual ICollection<Comment> Comments { get; set; }
        [InverseProperty(nameof(Document.Task))]
        public virtual ICollection<Document> Documents { get; set; }
    }
}
