﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ProjectP.Models
{
    [Table("User")]
    public partial class User
    {
        public User()
        {
            Comments = new HashSet<Comment>();
            Logs = new HashSet<Log>();
            Notifications = new HashSet<Notification>();
            Tasks = new HashSet<Task>();
            UserProjects = new HashSet<UserProject>();
        }

        [Key]
        public int UserId { get; set; }
        [Column("username")]
        [StringLength(50)]
        public string Username { get; set; }
        [Column("email")]
        [StringLength(50)]
        public string Email { get; set; }
        [Column("role")]
        public int? Role { get; set; }

        [InverseProperty(nameof(Comment.User))]
        public virtual ICollection<Comment> Comments { get; set; }
        [InverseProperty(nameof(Log.User))]
        public virtual ICollection<Log> Logs { get; set; }
        [InverseProperty(nameof(Notification.User))]
        public virtual ICollection<Notification> Notifications { get; set; }
        [InverseProperty(nameof(Task.User))]
        public virtual ICollection<Task> Tasks { get; set; }
        [InverseProperty(nameof(UserProject.User))]
        public virtual ICollection<UserProject> UserProjects { get; set; }
    }
}
