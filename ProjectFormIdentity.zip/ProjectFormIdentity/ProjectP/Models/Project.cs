﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ProjectP.Models
{
    [Table("Project")]
    public partial class Project
    {
        public Project()
        {
            Tasks = new HashSet<Task>();
            UserProjects = new HashSet<UserProject>();
        }

        [Key]
        [Column("projectId")]
        public int ProjectId { get; set; }
        [Column("projectName")]
        [StringLength(50)]
        public string ProjectName { get; set; }
        [Column("projectDescription")]
        [StringLength(50)]
        public string ProjectDescription { get; set; }
        [Column("projectManager")]
        public int? ProjectManager { get; set; }
        [Column("startDate", TypeName = "date")]
        public DateTime? StartDate { get; set; }
        [Column("dueDate", TypeName = "date")]
        public DateTime? DueDate { get; set; }

        [InverseProperty(nameof(Task.Project))]
        public virtual ICollection<Task> Tasks { get; set; }
        [InverseProperty(nameof(UserProject.Project))]
        public virtual ICollection<UserProject> UserProjects { get; set; }
    }
}
