﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ProjectP.Models
{
    [Table("Document")]
    public partial class Document
    {
        [Key]
        [Column("documentId")]
        public int DocumentId { get; set; }
        [Column("documentName")]
        [StringLength(50)]
        public string DocumentName { get; set; }
        [Column("documentUser")]
        [StringLength(50)]
        public string DocumentUser { get; set; }
        [Column("documentUploadDate", TypeName = "date")]
        public DateTime? DocumentUploadDate { get; set; }
        [Column("documentType")]
        [StringLength(50)]
        public string DocumentType { get; set; }
        [Column("documentBinaryData")]
        public bool? DocumentBinaryData { get; set; }
        [Column("taskId")]
        public int TaskId { get; set; }

        [ForeignKey(nameof(TaskId))]
        [InverseProperty("Documents")]
        public virtual Task Task { get; set; }
    }
}
