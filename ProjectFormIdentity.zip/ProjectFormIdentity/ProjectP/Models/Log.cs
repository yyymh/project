﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace ProjectP.Models
{
    [Table("Log")]
    public partial class Log
    {
        [Key]
        [Column("logId")]
        public int LogId { get; set; }
        [Column("logSource")]
        [StringLength(50)]
        public string LogSource { get; set; }
        [Column("logType")]
        [StringLength(50)]
        public string LogType { get; set; }
        [Column("userId")]
        public int? UserId { get; set; }
        [Column("logDate", TypeName = "date")]
        public DateTime? LogDate { get; set; }
        [Column("logMessage")]
        [StringLength(50)]
        public string LogMessage { get; set; }
        [Column("logOriginalValue", TypeName = "datetime")]
        public DateTime? LogOriginalValue { get; set; }
        [Column("logCurrentValue", TypeName = "datetime")]
        public DateTime? LogCurrentValue { get; set; }

        [ForeignKey(nameof(UserId))]
        [InverseProperty("Logs")]
        public virtual User User { get; set; }
    }
}
