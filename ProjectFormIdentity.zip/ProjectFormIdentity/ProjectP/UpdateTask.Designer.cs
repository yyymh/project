﻿namespace ProjectP
{
    partial class UpdateTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateTask));
            lblEmployeeName = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            panel1 = new System.Windows.Forms.Panel();
            label6 = new System.Windows.Forms.Label();
            comboBox1 = new System.Windows.Forms.ComboBox();
            richTextBox1 = new System.Windows.Forms.RichTextBox();
            btnDeleteDependant = new System.Windows.Forms.Button();
            btnAddDependant = new System.Windows.Forms.Button();
            txtRelationship = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            dgvDependants = new System.Windows.Forms.DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDependants).BeginInit();
            SuspendLayout();
            // 
            // lblEmployeeName
            // 
            lblEmployeeName.AutoSize = true;
            lblEmployeeName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblEmployeeName.Location = new System.Drawing.Point(238, 127);
            lblEmployeeName.Name = "lblEmployeeName";
            lblEmployeeName.Size = new System.Drawing.Size(89, 21);
            lblEmployeeName.TabIndex = 28;
            lblEmployeeName.Text = "TaskName";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(130, 127);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(104, 21);
            label1.TabIndex = 27;
            label1.Text = "Task Selected:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = System.Drawing.Color.Transparent;
            label4.Font = new System.Drawing.Font("Lucida Bright", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label4.ForeColor = System.Drawing.Color.White;
            label4.Location = new System.Drawing.Point(28, 3);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(377, 33);
            label4.TabIndex = 0;
            label4.Text = "Task Management System";
            // 
            // panel1
            // 
            panel1.BackgroundImage = (System.Drawing.Image)resources.GetObject("panel1.BackgroundImage");
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label4);
            panel1.Location = new System.Drawing.Point(2, 3);
            panel1.Name = "panel1";
            panel1.Size = new System.Drawing.Size(876, 84);
            panel1.TabIndex = 29;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(733, 46);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(70, 15);
            label6.TabIndex = 13;
            label6.Text = "Modify Task";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new System.Drawing.Point(644, 252);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new System.Drawing.Size(173, 23);
            comboBox1.TabIndex = 38;
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new System.Drawing.Point(644, 171);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new System.Drawing.Size(173, 75);
            richTextBox1.TabIndex = 37;
            richTextBox1.Text = "";
            // 
            // btnDeleteDependant
            // 
            btnDeleteDependant.BackColor = System.Drawing.Color.Firebrick;
            btnDeleteDependant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnDeleteDependant.ForeColor = System.Drawing.Color.White;
            btnDeleteDependant.Location = new System.Drawing.Point(563, 411);
            btnDeleteDependant.Name = "btnDeleteDependant";
            btnDeleteDependant.Size = new System.Drawing.Size(254, 23);
            btnDeleteDependant.TabIndex = 36;
            btnDeleteDependant.Text = "Close";
            btnDeleteDependant.UseVisualStyleBackColor = false;
            // 
            // btnAddDependant
            // 
            btnAddDependant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnAddDependant.Location = new System.Drawing.Point(563, 382);
            btnAddDependant.Name = "btnAddDependant";
            btnAddDependant.Size = new System.Drawing.Size(254, 23);
            btnAddDependant.TabIndex = 35;
            btnAddDependant.Text = "Update";
            btnAddDependant.UseVisualStyleBackColor = true;
            // 
            // txtRelationship
            // 
            txtRelationship.Location = new System.Drawing.Point(644, 281);
            txtRelationship.Name = "txtRelationship";
            txtRelationship.Size = new System.Drawing.Size(173, 23);
            txtRelationship.TabIndex = 34;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(544, 289);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(94, 15);
            label5.TabIndex = 33;
            label5.Text = "Add Comments:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(591, 260);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(42, 15);
            label3.TabIndex = 32;
            label3.Text = "Status:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(563, 178);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(70, 15);
            label2.TabIndex = 31;
            label2.Text = "Description:";
            // 
            // dgvDependants
            // 
            dgvDependants.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dgvDependants.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvDependants.Location = new System.Drawing.Point(30, 171);
            dgvDependants.Name = "dgvDependants";
            dgvDependants.ReadOnly = true;
            dgvDependants.RowHeadersWidth = 82;
            dgvDependants.RowTemplate.Height = 25;
            dgvDependants.Size = new System.Drawing.Size(489, 263);
            dgvDependants.TabIndex = 30;
            // 
            // UpdateTask
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(872, 480);
            Controls.Add(lblEmployeeName);
            Controls.Add(label1);
            Controls.Add(panel1);
            Controls.Add(comboBox1);
            Controls.Add(richTextBox1);
            Controls.Add(btnDeleteDependant);
            Controls.Add(btnAddDependant);
            Controls.Add(txtRelationship);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(dgvDependants);
            Name = "UpdateTask";
            Text = "UpdateTask";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvDependants).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnDeleteDependant;
        private System.Windows.Forms.Button btnAddDependant;
        private System.Windows.Forms.TextBox txtRelationship;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvDependants;
    }
}