﻿namespace ProjectP
{
    partial class CreateTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCancel = new System.Windows.Forms.Button();
            btnSave = new System.Windows.Forms.Button();
            groupBox1 = new System.Windows.Forms.GroupBox();
            dtpDueDate = new System.Windows.Forms.DateTimePicker();
            button1 = new System.Windows.Forms.Button();
            ddlAssignMember = new System.Windows.Forms.ComboBox();
            label1 = new System.Windows.Forms.Label();
            ddlStatus = new System.Windows.Forms.ComboBox();
            txtTaskDescription = new System.Windows.Forms.RichTextBox();
            txtTaskName = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            txtOrderID = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            dataGridView1 = new System.Windows.Forms.DataGridView();
            dtpStartDate = new System.Windows.Forms.DateTimePicker();
            label7 = new System.Windows.Forms.Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnCancel
            // 
            btnCancel.BackColor = System.Drawing.Color.Firebrick;
            btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnCancel.ForeColor = System.Drawing.Color.White;
            btnCancel.Location = new System.Drawing.Point(319, 418);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new System.Drawing.Size(123, 28);
            btnCancel.TabIndex = 30;
            btnCancel.Text = "Close";
            btnCancel.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            btnSave.BackColor = System.Drawing.Color.FromArgb(1, 90, 132);
            btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            btnSave.ForeColor = System.Drawing.Color.White;
            btnSave.Location = new System.Drawing.Point(10, 418);
            btnSave.Name = "btnSave";
            btnSave.Size = new System.Drawing.Size(121, 28);
            btnSave.TabIndex = 29;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = false;
            btnSave.Click += btnSave_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(dtpStartDate);
            groupBox1.Controls.Add(dtpDueDate);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(ddlAssignMember);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(ddlStatus);
            groupBox1.Controls.Add(txtTaskDescription);
            groupBox1.Controls.Add(txtTaskName);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(txtOrderID);
            groupBox1.Controls.Add(label5);
            groupBox1.Location = new System.Drawing.Point(10, 9);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new System.Drawing.Size(462, 403);
            groupBox1.TabIndex = 28;
            groupBox1.TabStop = false;
            groupBox1.Text = "Task";
            // 
            // dtpDueDate
            // 
            dtpDueDate.Location = new System.Drawing.Point(123, 317);
            dtpDueDate.Name = "dtpDueDate";
            dtpDueDate.Size = new System.Drawing.Size(217, 23);
            dtpDueDate.TabIndex = 25;
            // 
            // button1
            // 
            button1.BackColor = System.Drawing.Color.FromArgb(1, 90, 132);
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.ForeColor = System.Drawing.Color.White;
            button1.Location = new System.Drawing.Point(356, 296);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(86, 28);
            button1.TabIndex = 24;
            button1.Text = "Add";
            button1.UseVisualStyleBackColor = false;
            // 
            // ddlAssignMember
            // 
            ddlAssignMember.FormattingEnabled = true;
            ddlAssignMember.Location = new System.Drawing.Point(123, 365);
            ddlAssignMember.Name = "ddlAssignMember";
            ddlAssignMember.Size = new System.Drawing.Size(217, 23);
            ddlAssignMember.TabIndex = 17;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(16, 373);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(45, 15);
            label1.TabIndex = 16;
            label1.Text = "Assign:";
            // 
            // ddlStatus
            // 
            ddlStatus.FormattingEnabled = true;
            ddlStatus.Location = new System.Drawing.Point(123, 220);
            ddlStatus.Name = "ddlStatus";
            ddlStatus.Size = new System.Drawing.Size(217, 23);
            ddlStatus.TabIndex = 15;
            // 
            // txtTaskDescription
            // 
            txtTaskDescription.Location = new System.Drawing.Point(123, 109);
            txtTaskDescription.Name = "txtTaskDescription";
            txtTaskDescription.Size = new System.Drawing.Size(217, 96);
            txtTaskDescription.TabIndex = 14;
            txtTaskDescription.Text = "";
            // 
            // txtTaskName
            // 
            txtTaskName.Location = new System.Drawing.Point(123, 62);
            txtTaskName.Name = "txtTaskName";
            txtTaskName.Size = new System.Drawing.Size(217, 23);
            txtTaskName.TabIndex = 13;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(16, 33);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(46, 15);
            label2.TabIndex = 1;
            label2.Text = "Task ID:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(16, 66);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(42, 15);
            label3.TabIndex = 2;
            label3.Text = "Name:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(16, 95);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(70, 15);
            label4.TabIndex = 3;
            label4.Text = "Description:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(16, 317);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(58, 15);
            label6.TabIndex = 5;
            label6.Text = "Due Date:";
            // 
            // txtOrderID
            // 
            txtOrderID.Location = new System.Drawing.Point(123, 33);
            txtOrderID.Name = "txtOrderID";
            txtOrderID.ReadOnly = true;
            txtOrderID.Size = new System.Drawing.Size(217, 23);
            txtOrderID.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(16, 228);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(42, 15);
            label5.TabIndex = 4;
            label5.Text = "Status:";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new System.Drawing.Point(490, 26);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new System.Drawing.Size(421, 328);
            dataGridView1.TabIndex = 31;
            // 
            // dtpStartDate
            // 
            dtpStartDate.Location = new System.Drawing.Point(123, 267);
            dtpStartDate.Name = "dtpStartDate";
            dtpStartDate.Size = new System.Drawing.Size(217, 23);
            dtpStartDate.TabIndex = 32;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(13, 275);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(61, 15);
            label7.TabIndex = 33;
            label7.Text = "Start Date:";
            // 
            // CreateTask
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(970, 450);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(groupBox1);
            Controls.Add(dataGridView1);
            Name = "CreateTask";
            Text = "CreateTask";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox ddlAssignMember;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ddlStatus;
        private System.Windows.Forms.RichTextBox txtTaskDescription;
        private System.Windows.Forms.TextBox txtTaskName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtOrderID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DateTimePicker dtpDueDate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpStartDate;
    }
}